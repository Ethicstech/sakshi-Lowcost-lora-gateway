#!/bin/sh

cd /home/pi/lora_gateway
python start_gw.py &
